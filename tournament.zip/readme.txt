1. To run this program, save to a tournament_test.py, tournament.py, & tournament.sql to a location on your PC and note the file location.
2. Goto your terminal on a MAC or command prompt on a PC and navigate to the location of where you saved the three files.
3. Type the following "python tournament_test.py" to test if the file passes the tournament_test.py file. 